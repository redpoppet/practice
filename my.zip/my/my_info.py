my_info='aaa'
print('ok')
